# Shivam Game Development & Testing Portfolio

A responsive single-file portfolio covering programming languages, game engines, graphics, tools and a professional game QA/testing workflow.

## Main sections
- Programming languages: C++, C#, C, GDScript, Lua, Python, JavaScript, TypeScript, Java, SQL, GLSL, HLSL, JSON, Bash
- Engines/tools: Unreal, Unity, Godot, Blender, Git, CI/CD, APIs, AI
- QA workflow: planning, functional testing, bug hunting, performance, multiplayer and regression
- Shivam profile section

Upload `index.html` to GitHub Pages, Netlify, Vercel, or another static host.
