# Shivam Gaming × Coding Portfolio

A single-file responsive portfolio website with:
- Coding/terminal animation-style section
- Shivam profile card
- Gaming lineup
- Neon gaming/coding design
- Mobile responsive layout

## Upload
Upload `index.html` to GitHub Pages, Netlify, Vercel, or any static hosting service.
